# Fundbüro – Streamlit Mobile App

Enthält:
- mobile-first Smartphone-Oberfläche
- Foto-Upload/Kamera-Upload
- integrierte KI zur Erkennung der mitgelieferten 4 Klassen
- automatische Kategorie-Vorschläge
- integrierte Fundort-Karte
- SQLite-Datenbank

## Start
```bash
pip install -r requirements.txt
streamlit run app.py
```

Die KI-Klassen aus `ai_model/labels.txt` sind: Flaschen, Hose, Jacken, Federtasche.
