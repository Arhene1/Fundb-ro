"""
fundbuero_ki.py
----------------
Python-Integration des mitgelieferten Fundbüro-KI-Modells.

Das Modell ist ein Keras-Modell. Python lädt die Modelldatei und
wandelt hochgeladene Fotos in die passende Eingabegröße um.

Klassen des Modells werden aus labels.txt geladen.
"""

from pathlib import Path
from typing import BinaryIO, Tuple, Optional

import numpy as np
from PIL import Image

try:
    import tensorflow as tf
except ImportError:
    tf = None


BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "keras_model.h5"
LABEL_PATH = BASE_DIR / "labels.txt"


def load_labels():
    """Lädt die Klassenbezeichnungen aus labels.txt."""
    labels = []

    if not LABEL_PATH.exists():
        raise FileNotFoundError(f"Labels fehlen: {LABEL_PATH}")

    for line in LABEL_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()

        if not line:
            continue

        # Unterstützt:
        #   0 Flaschen
        #   Flaschen
        parts = line.split(maxsplit=1)

        if len(parts) == 2 and parts[0].isdigit():
            labels.append(parts[1].strip())
        else:
            labels.append(line)

    return labels


def load_model():
    """Lädt das trainierte Keras-Modell."""
    if tf is None:
        raise ImportError(
            "TensorFlow fehlt. Installiere es mit: pip install tensorflow"
        )

    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"KI-Modell fehlt: {MODEL_PATH}")

    return tf.keras.models.load_model(
        MODEL_PATH,
        compile=False,
    )


def recognize_image(image) -> Tuple[str, float]:
    """
    Erkennt einen Gegenstand auf einem Bild.

    Parameter:
        image:
            PIL.Image, Dateipfad oder Dateiobjekt.

    Rückgabe:
        (erkannte_klasse, sicherheit)
    """

    model = load_model()
    labels = load_labels()

    if isinstance(image, (str, Path)):
        image = Image.open(image)

    elif hasattr(image, "read"):
        image = Image.open(image)

    image = image.convert("RGB")

    # Das mitgelieferte Modell verwendet 224x224 RGB.
    image = image.resize((224, 224))

    image_array = np.asarray(
        image,
        dtype=np.float32,
    ) / 255.0

    input_data = np.expand_dims(
        image_array,
        axis=0,
    )

    prediction = model.predict(
        input_data,
        verbose=0,
    )

    prediction = np.asarray(prediction).reshape(-1)

    class_index = int(np.argmax(prediction))
    confidence = float(prediction[class_index])

    if class_index < len(labels):
        label = labels[class_index]
    else:
        label = f"Klasse {class_index}"

    confidence = max(
        0.0,
        min(1.0, confidence),
    )

    return label, confidence


def recognize_file(file_path: str):
    """Einfache Funktion für ein lokales Foto."""
    return recognize_image(file_path)


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 2:
        print("Verwendung:")
        print("python fundbuero_ki.py foto.jpg")
        raise SystemExit(1)

    label, confidence = recognize_file(sys.argv[1])

    print(f"Erkannt: {label}")
    print(f"Sicherheit: {confidence:.1%}")
