# Fundbüro – Streamlit + integrierte KI

Start:
```bash
pip install -r requirements.txt
streamlit run app.py
```

Die KI ist direkt in `app.py` integriert. Das trainierte Modell bleibt als `keras_model.h5`.
