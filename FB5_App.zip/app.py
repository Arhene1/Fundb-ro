import streamlit as st
from pathlib import Path
import sqlite3
import uuid
from datetime import datetime

import numpy as np
from PIL import Image
import tensorflow as tf
import pandas as pd
import folium
from streamlit_folium import st_folium

st.set_page_config(page_title="Fundbüro", page_icon="🔎", layout="centered")

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "keras_model.h5"
UPLOAD_DIR = BASE_DIR / "uploads"
DB_PATH = BASE_DIR / "fundbuero.db"
UPLOAD_DIR.mkdir(exist_ok=True)

AI_LABELS = ['Flaschen', 'Hose', 'Jacken', 'Federtasche']

st.markdown("""
<style>
.stApp { background:#fff; color:#111; }
.block-container { max-width:620px; padding:1rem .8rem 4rem; }
div.stButton > button, div[data-testid="stFormSubmitButton"] button {
    width:100%; min-height:48px; border-radius:12px; font-weight:600;
}
div[data-testid="stFileUploader"] {
    border:2px dashed #8ecdf5; border-radius:14px; padding:.5rem;
    background:#f4fbff;
}
.ai-box { background:#eef8ff; border:1px solid #b7e1fb; border-radius:14px;
    padding:1rem; margin:.75rem 0; }
.ai-title { color:#0879c9; font-weight:700; }
.ai-result { font-size:1.35rem; font-weight:800; }
.muted { color:#666; font-size:.9rem; }
</style>
""", unsafe_allow_html=True)

def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.execute("""
    CREATE TABLE IF NOT EXISTS fundstuecke (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        titel TEXT NOT NULL,
        kategorie TEXT,
        beschreibung TEXT,
        fundort TEXT,
        latitude REAL,
        longitude REAL,
        status TEXT DEFAULT 'Gefunden',
        foto TEXT,
        ki_label TEXT,
        ki_confidence REAL,
        created_at TEXT NOT NULL
    )
    """)
    cols = {r["name"] for r in c.execute("PRAGMA table_info(fundstuecke)")}
    for name, typ in {
        "latitude":"REAL", "longitude":"REAL", "foto":"TEXT",
        "ki_label":"TEXT", "ki_confidence":"REAL"
    }.items():
        if name not in cols:
            c.execute(f"ALTER TABLE fundstuecke ADD COLUMN {name} {typ}")
    c.commit()
    c.close()

init_db()

@st.cache_resource
def load_ai_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Modell fehlt: {MODEL_PATH}")
    return tf.keras.models.load_model(MODEL_PATH, compile=False)

def recognize_image(image):
    model = load_ai_model()
    image = image.convert("RGB").resize((224, 224))
    arr = np.asarray(image, dtype=np.float32) / 255.0
    pred = np.asarray(model.predict(np.expand_dims(arr, 0), verbose=0)).reshape(-1)
    idx = int(np.argmax(pred))
    confidence = float(pred[idx])
    label = AI_LABELS[idx] if idx < len(AI_LABELS) else f"Klasse {idx}"
    return label, confidence

st.title("🔎 Fundbüro")
st.caption("Fundstücke melden, automatisch erkennen und verwalten.")

page = st.radio("Bereich",
                ["Fundstück melden", "Übersicht", "Karte", "Verwaltung"],
                horizontal=True)

if page == "Fundstück melden":
    st.header("Fundstück melden")

    photo = st.file_uploader(
        "Foto aufnehmen oder auswählen",
        type=["jpg", "jpeg", "png", "webp"]
    )

    ai_label = None
    ai_confidence = None

    if photo:
        image = Image.open(photo)
        st.image(image, caption="Foto", use_container_width=True)

        with st.spinner("KI analysiert das Fundstück ..."):
            try:
                ai_label, ai_confidence = recognize_image(image)
                st.markdown(
                    f"""<div class="ai-box">
                    <div class="ai-title">🤖 KI-Erkennung</div>
                    <div class="ai-result">{ai_label}</div>
                    <div class="muted">Sicherheit: {ai_confidence*100:.1f} %</div>
                    </div>""",
                    unsafe_allow_html=True
                )
                if ai_confidence < 0.60:
                    st.warning("Die KI ist sich nicht sehr sicher. Bitte Kategorie prüfen.")
            except Exception as e:
                st.error(f"KI-Fehler: {e}")

    categories = ["Flaschen", "Hose", "Jacken", "Federtasche", "Sonstiges"]
    default = categories.index(ai_label) if ai_label in categories else 0

    category = st.selectbox("Kategorie", categories, index=default)
    title = st.text_input("Titel", placeholder="z. B. Schwarze Jacke")
    description = st.text_area("Beschreibung")
    location = st.text_input("Fundort", placeholder="z. B. Bahnhof Schleswig")

    c1, c2 = st.columns(2)
    with c1:
        lat = st.number_input("Breitengrad", value=0.0, format="%.6f")
    with c2:
        lon = st.number_input("Längengrad", value=0.0, format="%.6f")

    if st.button("Fundstück speichern", type="primary"):
        if not title.strip():
            st.error("Bitte einen Titel eingeben.")
        else:
            photo_path = None
            if photo:
                suffix = Path(photo.name).suffix.lower() or ".jpg"
                photo_path = UPLOAD_DIR / f"{uuid.uuid4().hex}{suffix}"
                photo_path.write_bytes(photo.getbuffer())

            c = db()
            c.execute("""
            INSERT INTO fundstuecke
            (titel,kategorie,beschreibung,fundort,latitude,longitude,status,
             foto,ki_label,ki_confidence,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, (
                title.strip(), category, description.strip(), location.strip(),
                lat or None, lon or None, "Gefunden",
                str(photo_path) if photo_path else None,
                ai_label, ai_confidence,
                datetime.now().isoformat(timespec="seconds")
            ))
            c.commit()
            c.close()
            st.success("Fundstück gespeichert.")
            st.rerun()

elif page == "Übersicht":
    st.header("Gefundene Gegenstände")
    c = db()
    rows = c.execute("SELECT * FROM fundstuecke ORDER BY id DESC").fetchall()
    c.close()

    if not rows:
        st.info("Noch keine Fundstücke vorhanden.")
    for row in rows:
        with st.container(border=True):
            if row["foto"] and Path(row["foto"]).exists():
                st.image(row["foto"], use_container_width=True)
            st.subheader(row["titel"])
            if row["kategorie"]:
                st.write(f"**Kategorie:** {row['kategorie']}")
            if row["fundort"]:
                st.write(f"📍 **Fundort:** {row['fundort']}")
            if row["beschreibung"]:
                st.write(row["beschreibung"])
            if row["ki_label"]:
                conf = (row["ki_confidence"] or 0) * 100
                st.caption(f"🤖 KI: {row['ki_label']} ({conf:.1f} %)")
            st.caption(f"Status: {row['status']} · {row['created_at']}")

elif page == "Karte":
    st.header("🗺️ Fundorte")
    c = db()
    rows = c.execute("""
        SELECT * FROM fundstuecke
        WHERE latitude IS NOT NULL AND longitude IS NOT NULL
        ORDER BY id DESC
    """).fetchall()
    c.close()

    if not rows:
        st.info("Keine Fundstücke mit Koordinaten vorhanden.")
    else:
        fmap = folium.Map([rows[0]["latitude"], rows[0]["longitude"]], zoom_start=13)
        for row in rows:
            folium.Marker(
                [row["latitude"], row["longitude"]],
                tooltip=row["titel"],
                popup=f"<b>{row['titel']}</b><br>{row['kategorie'] or ''}<br>{row['fundort'] or ''}"
            ).add_to(fmap)
        st_folium(fmap, width=None, height=500)

else:
    st.header("Verwaltung")
    c = db()
    rows = c.execute("SELECT * FROM fundstuecke ORDER BY id DESC").fetchall()
    c.close()

    st.metric("Fundstücke", len(rows))
    if rows:
        df = pd.DataFrame([dict(r) for r in rows])
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.download_button(
            "CSV exportieren",
            df.to_csv(index=False).encode("utf-8"),
            "fundstuecke.csv",
            "text/csv",
            use_container_width=True
        )

st.divider()
st.caption("Streamlit + TensorFlow/Keras · integrierte Objekterkennung")
